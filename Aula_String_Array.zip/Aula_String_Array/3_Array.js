let ask = require("readline-sync")

let typesDogs = ["Pug", "Shitzu", "Caramelo", "Husky Siberiano", "chiuaua"]


console.log(`${typesDogs.length}, Mas lembre, sempre comeca no 0`) //diz a quantidade de itens

let choice = typesDogs[ask.question("Me diga um num, que te digo uma raca. ")]
console.log(choice)


