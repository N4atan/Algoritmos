const ask = require("readline-sync")

let name = ask.question(`What's your name ? `)
let favoriteColor = ask.question(`What's your favorite color? `)

console.log(`The favorite color of ${name} is ${favoriteColor}.`)
console.log("A cor favorita de", name, "é", favoriteColor + ".")