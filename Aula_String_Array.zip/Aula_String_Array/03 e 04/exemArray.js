const listaCompra = ["batata", "alface", "queijo"]
const listaDeNumerosMega = [2, 14, 2561, 6337,]
//Pode ser mais de um tipo;
//Para puxar um item do array, acessar;

let listaDeCompras = listaCompra[2] //Alface

