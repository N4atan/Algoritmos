//Dado o array ["Banana", "Morango", "Abacaxi", "Laranja", "Ameixa"], faça um programa que acha o índice da palavra Abacaxi e imprime tanto o índice quanto o tamanho do array

let frutas = ["Banana", "Morango", "Abacaxi", "Laranja", "Ameixa"]

let findInd = frutas.indexOf("Abacaxi")
console.log(`O indicide da palavra abacaxi é: ${findInd}. E o tamanho dessa array é ${frutas.length}`)
