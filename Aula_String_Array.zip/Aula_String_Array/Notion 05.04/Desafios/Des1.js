//Receba uma frase e 
//retorne um array onde cada elemento é uma das palavras da frase, 
//ignorando os espaços

const ask = require("readline-sync")

let phrase = ask.question("Diz uma frase: ")

let arrayFrase = phrase.split(" ")
console.log(arrayFrase)

