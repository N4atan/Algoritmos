//2. Faça um programa que contenha um array com 5 das suas comidas preferidas, armazenado em uma variável. Em seguida, siga os passos:
    
//a) Imprima no console o array completo
    
//b) Imprima no console a mensagem "Essas são as minhas comidas preferidas: ", seguida por cada uma das comidas, **uma embaixo da outra**.

//c) Aqui vai um desafio: pergunte ao usuário uma comida preferida. Troque a segunda comida da sua lista pela inserida pelo usuário. Imprima no console a nova lista
const ask = require("readline-sync")

let favoriteFoods = ["Pizza", "Bolo", "Panqueca", "Maca", "Gelatina"]

console.log(`a. ${favoriteFoods} \n`)

console.log(`b. Essas são minhas comidas favoritas: \n${(favoriteFoods.join('\n'))}\n`)

let i = 1
favoriteFoods[i] = ask.question("Diga uma comida que voce gosta muito: " )


console.log(`\n --------------- \n c. A nova lista é: \n${favoriteFoods.join('\n')} \n `)