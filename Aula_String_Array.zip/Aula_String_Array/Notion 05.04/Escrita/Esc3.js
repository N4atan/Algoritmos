const ask = require("readline-sync")

let indicadorPergunta = 0
let listaTarefa = []

function perguntarTarefas(){
    listaTarefa.push(ask.question("Qual a Tarefa: "))

    listaTarefa.push(ask.question("Qual a Tarefa: "))
    listaTarefa.push(ask.question("Qual a Tarefa: "))
    console.log(listaTarefa)
    "\n"
}
perguntarTarefas()
let qualRealizada = Number(ask.question("Qual delas voce realizou: 1, 2 ou 3 ? ")) - 1
listaTarefa.splice(qualRealizada, 1) //conta ele mesmo como um número
console.log(listaTarefa)