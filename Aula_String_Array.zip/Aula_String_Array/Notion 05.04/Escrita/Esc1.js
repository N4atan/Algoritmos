//1. Faça um programa que pergunte ao usuário seu nome e seu e-mail. Em seguida, Imprima no console a seguinte mensagem:
    
//O e-mail `emailDoUsuario` foi cadastrado com sucesso. Seja bem-vinda(o), `nomeDoUsuario`!

const ask = require("readline-sync")
let nameUser
let emailUser

if (ask.question(`Quer cadastrar seu usuario? y/n. `)) {
    let nameUser = ask.question(`Qual seu nome? `)
    let emailUser = ask.question(`Qual seu email? `)
    console.log(`
    ------------------------------------
    O email ${emailUser} foi cadastrado com sucesso!
    BEM VINDO ${nameUser} !
    ------------------------------------`)
}