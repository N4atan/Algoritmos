//Indique todas as mensagens impressas no console, SEM EXECUTAR o programa.

let array
console.log('a. ', array) //a. indefinida

array = null
console.log('b. ', array) //b. null

array = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
console.log('c. ', array.length) //c. tamnaho da array

let i = 0 //aqui definimos i = 0 
console.log('d. ', array[i]) //acessamos o indici 'i' que é igual a 0, entao acessa o indicie 0 da array

array[i+1] = 19 //aqui dizemos que o indice 0 + 1 é igual a 19, substituindo o 4 por 19
console.log('e. ', array) // e. toda array

const valor = array[i+6] //definimos uma var igual ao numero que representa o indice i + 6
console.log('f. ', valor)//f. 9