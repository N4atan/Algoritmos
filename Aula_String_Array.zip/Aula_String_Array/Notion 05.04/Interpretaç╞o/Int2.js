const readlineSync = require('readline-sync');

const frase = readlineSync.question("Digite uma frase: ");

console.log(frase.toUpperCase().replaceAll("A", "I"), frase.length); //deixamos em maisculu, trocamos A por I, dizemos tamanho da string

//Qual será o valor impresso no console se a entrada do usuário for: "Subi num ônibus em Marrocos"? SUBI NUM ÔNIBUS EM MIRROCOS, 27