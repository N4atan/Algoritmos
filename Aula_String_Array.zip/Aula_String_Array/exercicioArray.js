//Para este exercício, comece criando um array com os valores: 1, 2,3, 4, 5 e 6.
//Determine o tamanho do array
//Adicione o número 7
//Remova os números 4 e 5
//Determine o novo tamanho do array

const ask = require("readline-sync")

let array = [1, 2, 3, 4, 5, 6]

console.log(`a nossa array é ${array}, e o tamnho dela e ${array.length}`)
console.log(`mas agora, vou adicionar mais um number nela! ${array.push(7)}`)
array.splice(3,2)
console.log(`Mas em contra partida, retirei 2 number.`)
console.log(`Agora, ela possui ${array.length} itens, e eles são ${array}. `)

let resposta = (ask.question(`Quais eu retirei? `))

if (resposta.includes("4") && resposta.includes("5")){
    console.log("---------------")
    console.log(`PARABENS ACERTOU !!`)
} else {
    console.log("--------------")
    console.log(`ERROU ANIMAL`)
}

